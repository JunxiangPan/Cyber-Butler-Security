# local agent RAG 知识库填充与调用指南

## Contents

- [一、上传前准备](#一上传前准备)
- [二、在 AgentRuntime WebUI 上传](#二在-agentruntime-webui-上传)
- [三、调用方式](#三调用方式)
- [四、验收标准](#四验收标准)
- [五、注意](#五注意)

> v1.6.1 status, incomplete work, and non-guarantees: archived v1.6.1 status (removed).


## 一、上传前准备

### 1. 部署说明

当前完整说明文件：

```text
YOUR_PROJECT_PATH\使用说明.md
```

先确认里面没有：

- DeepSeek / 其他 API Key
- QQ 密码、Token
- Windows 登录密码
- 个人身份信息

如果只是内部使用，可以把 Key 段落删掉再上传。

### 2. 电脑配置单

建议单独生成一份 `电脑配置单.md`，内容只放硬件和系统信息：

- CPU 型号
- 内存容量/频率
- GPU 型号/显存
- 主板/硬盘
- Windows 版本
- Ollama 模型名、上下文长度
- AgentRuntime 运行账户（可写“YOUR_SERVICE_USER”，不要写密码）
- 端口：6185 / 5099 / 11434 / 18085

不要把 `cmd_config.json`、`.agentruntime_token`、SSH 私钥上传到知识库。

## 二、在 AgentRuntime WebUI 上传

1. 浏览器打开：

```text
http://127.0.0.1:6185
```

2. 登录 AgentRuntime 管理后台。
3. 找到「知识库 / 知识库管理」页面。
4. 新建知识库，例如：

```text
local agent部署与主机手册
```

5. 上传：

```text
使用说明.md
电脑配置单.md
```

6. 建议切块参数：

| 参数 | 建议 |
|---|---|
| chunk size | 512–768 |
| overlap | 50–80 |
| topK | 4–5 |
| 清洗 | 可开，但不要用会改写事实的 LLM 清洗 |

7. 等待解析完成，确认文档状态为「已索引」。

## 三、调用方式

在 QQ 私聊里直接问，例如：

```text
瑾言，查一下知识库：这台电脑的 Ollama 主模型是什么？上下文多大？
```

```text
瑾言，根据知识库说明，每周日凌晨 4 点的自愈流程做了什么？
```

```text
瑾言，知识库里写的 AgentRuntime 运行账户和端口是什么？
```

```text
瑾言，游戏模式是怎么识别 Steam → 启动器 → 游戏本体的？
```

## 四、验收标准

| 问题 | 期望回答 |
|---|---|
| 主模型是什么 | `sujinyan-chat-24k`，24k 上下文，20GB / GPU |
| AgentRuntime 运行账户 | `YOUR_SERVICE_USER` |
| AuxRuntime 运行账户 | `test-user` |
| 每周自愈时间 | 周日 04:00 |
| AgentRuntime 端口 | 6185 |
| AuxRuntime 端口 | 5099 |
| Ollama 端口 | 11434 |
| 游戏模式检测 | 进程树 + GPU 兜底 + 45 秒宽限 |

如果回答“知识库里没有”，先检查：

1. 文档是否索引完成；
2. 问法是否太短（建议带上“根据知识库/部署说明”）；
3. topK 是否太小；
4. embedding 模型 `bge-m3-cpu:latest` 是否存在：

```bash
ollama list | findstr bge-m3
```

## 五、注意

- 知识库是“检索增强”，不是重新训练模型；答案依赖上传文档的完整度。
- 配置单里的端口/账户是静态事实，更新后要重新上传。
- 不要把 API Key 放进知识库；Key 已迁移到 DPAPI 加密文件。
- 如果 AgentRuntime 升级覆盖了 `web_search_tools.py` 的 `$ENV` 支持，需要重新应用补丁；升级前先备份。
