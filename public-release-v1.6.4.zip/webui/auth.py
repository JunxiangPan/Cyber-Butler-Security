from __future__ import annotations

import logging
import secrets
import time
from collections import defaultdict, deque

from settings import Settings
from store import Store, otp_digest

logger = logging.getLogger("cyberbutler.webui.auth")

SESSION_COOKIE = "cb_web_session"


class RateLimited(Exception):
    """RateLimited helper/type."""
    def __init__(self, retry_after: int = 60):
        """Init.
        
        Args:
            retry_after: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        self.retry_after = retry_after
        super().__init__("rate limited")


class InvalidCode(Exception):
    """InvalidCode helper/type."""
    pass


class MailerFailed(Exception):
    """MailerFailed helper/type."""
    pass


class UnknownEmail(Exception):
    """UnknownEmail helper/type."""
    pass


class RateLimiter:
    """RateLimiter helper/type."""
    def __init__(self) -> None:
        """Init.
        
        Args:
            None.
        
        Returns:
            Function result, or None when no value is returned.
        """
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def allow(self, key: str, limit: int, window: int) -> bool:
        """Allow.
        
        Args:
            key: caller-supplied value.
            limit: caller-supplied value.
            window: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        now = time.monotonic()
        if len(self._hits) > 256:
            for old_key, old_bucket in list(self._hits.items()):
                if not old_bucket or now - old_bucket[-1] > 3600:
                    self._hits.pop(old_key, None)
        bucket = self._hits[key]
        while bucket and now - bucket[0] > window:
            bucket.popleft()
        if len(bucket) >= limit:
            return False
        bucket.append(now)
        return True

    def forget(self, key: str) -> None:
        """Forget.
        
        Args:
            key: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        self._hits.pop(key, None)
        self._hits.pop("cooldown:" + key, None)

    def cooldown(self, key: str, seconds: int) -> bool:
        """Cooldown.
        
        Args:
            key: caller-supplied value.
            seconds: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        now = time.monotonic()
        bucket = self._hits["cooldown:" + key]
        while bucket and now - bucket[0] > seconds:
            bucket.popleft()
        if bucket:
            return False
        bucket.append(now)
        return True


class AuthService:
    """AuthService helper/type."""
    def __init__(self, settings: Settings, store: Store, mailer) -> None:
        """Init.
        
        Args:
            settings: caller-supplied value.
            store: caller-supplied value.
            mailer: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        self.settings = settings
        self.store = store
        self.mailer = mailer
        self.limiter = RateLimiter()

    async def request_otp(self, email: str, ip: str, lang: str = "zh") -> None:
        """Request otp.
        
        Args:
            email: caller-supplied value.
            ip: caller-supplied value.
            lang: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        email = email.strip().lower()
        # Keep the public response generic for an unknown address, but do not
        # consume the IP budget: otherwise a typo silently becomes a lockout.
        if email != self.settings.admin_email:
            return
        if not self.limiter.allow("otp-ip:" + ip, 15, 300):
            raise RateLimited(300)
        if not self.limiter.cooldown("otp-email:" + email, 60):
            raise RateLimited(60)
        if not self.limiter.allow("otp-email-window:" + email, 3, 300):
            raise RateLimited(300)

        code = f"{secrets.randbelow(1_000_000):06d}"
        salt = secrets.token_hex(16)
        self.store.create_otp(email, code, salt, self.settings.otp_ttl_seconds)
        try:
            await self.mailer.send(email, code, self.settings.otp_ttl_seconds, lang)
        except Exception as exc:
            logger.error("OTP mail delivery failed: %s", exc)
            # Do not punish the operator for a failed SMTP attempt; otherwise
            # a transient mail failure becomes a 60-second/5-minute lockout.
            self.limiter.forget("otp-ip:" + ip)
            self.limiter.forget("otp-email:" + email)
            self.limiter.forget("otp-email-window:" + email)
            raise MailerFailed("verification mail could not be sent") from exc

    def verify(self, email: str, code: str, ip: str) -> tuple[str, str]:
        """Verify.
        
        Args:
            email: caller-supplied value.
            code: caller-supplied value.
            ip: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        email = email.strip().lower()
        if not self.limiter.allow("verify-ip:" + ip, 20, 300):
            raise RateLimited(300)
        otp = self.store.latest_otp(email)
        if not otp:
            raise InvalidCode("no active code")
        now = int(time.time())
        if now > int(otp["expires_at"]) or int(otp["attempts"]) >= self.settings.otp_max_attempts:
            raise InvalidCode("code expired or locked")
        expected = otp_digest(self.settings.server_secret, email, code, otp["salt"])
        if not secrets.compare_digest(expected, otp["code_hash"]):
            attempts = self.store.bump_otp_attempts(otp["id"])
            if attempts >= self.settings.otp_max_attempts:
                raise InvalidCode("too many attempts")
            raise InvalidCode("incorrect code")
        self.store.use_otp(otp["id"])
        token = secrets.token_urlsafe(32)
        csrf = secrets.token_urlsafe(32)
        self.store.create_session(email, token, csrf, self.settings.session_days)
        return token, csrf

    def session(self, token: str | None) -> dict | None:
        """Session.
        
        Args:
            token: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        if not token:
            return None
        return self.store.get_session(token, self.settings.idle_hours)

    def logout(self, token: str | None) -> None:
        """Logout.
        
        Args:
            token: caller-supplied value.
        
        Returns:
            Function result, or None when no value is returned.
        """
        if token:
            self.store.delete_session(token)
