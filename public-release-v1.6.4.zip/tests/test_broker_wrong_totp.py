"""Broker denies an invalid TOTP with HTTP 403."""

from __future__ import annotations

import time

import broker


def setup_function() -> None:
    broker.broker_state._pending = None
    broker.broker_state._verify_locked_until = 0.0
    broker.broker_state._global_failures = 0
    broker.broker_state._global_lock_until = 0.0
    broker.broker_state._used_totp.clear()


def test_wrong_totp_returns_403(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(broker, "verify_code", lambda code, request_id="": "")
    monkeypatch.setattr(broker, "AUDIT", tmp_path / "broker-audit.jsonl")

    broker.broker_state._pending = {
        "id": "req-test",
        "action": "delete",
        "target": "YOUR_USER_PATH/Desktop/shared/note.txt",
        "source": "",
        "reason": "test",
        "deadline": time.monotonic() + 60,
    }

    status, body = broker.run_verify({"id": "req-test", "code": "000000"})

    assert status == 403
    assert body["ok"] is False
    assert body["error"] == "invalid verification code"
    assert body["attempts"] == 1
    assert broker.broker_state._pending is not None  # invalid code does not consume the challenge
    assert broker.broker_state._pending["attempts"] == 1
    assert (tmp_path / "broker-audit.jsonl").exists()
