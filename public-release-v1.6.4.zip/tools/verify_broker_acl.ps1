# Fail-closed check for the SYSTEM Broker runtime.
# Run from tools/broker.py startup, and also manually before deploying.
param(
    [string]$ServiceUser = 'YOUR_SERVICE_USER',
    [string]$DesktopUser = 'test-user'
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$paths = @(
    (Join-Path $root 'tools'),
    (Join-Path $root 'webui\.venv')
)
$bad = New-Object System.Collections.Generic.List[string]
$writeMask = 'Write|Modify|FullControl|TakeOwnership|ChangePermissions'
$broadPrincipals = 'Users|Everyone|Authenticated Users|' + [regex]::Escape($DesktopUser) + '|' + [regex]::Escape($ServiceUser)

foreach ($path in $paths) {
    if (-not (Test-Path -LiteralPath $path)) {
        $bad.Add("missing path: $path")
        continue
    }
    $acl = Get-Acl -LiteralPath $path
    if ($acl.Owner -notmatch 'SYSTEM|Administrators') {
        $bad.Add("owner is not SYSTEM/Administrators: $path ($($acl.Owner))")
    }
    foreach ($ace in @($acl.Access)) {
        if ($ace.AccessControlType -ne 'Allow') { continue }
        if ($ace.FileSystemRights -match $writeMask -and
            $ace.IdentityReference -match $broadPrincipals) {
            $bad.Add("broad or service write ACE: $path <- $($ace.IdentityReference) $($ace.FileSystemRights)")
        }
    }
}

$vault = Join-Path (Join-Path $root 'tools') 'totp-vault'
$secretPaths = @(
    (Join-Path $vault 'totp_secret.dpapi'),
    (Join-Path (Join-Path $root 'tools') 'totp_secret.dpapi')
)
$recoveryPaths = @(
    (Join-Path $vault 'recovery_hashes.json'),
    (Join-Path (Join-Path $root 'tools') 'totp_recovery.json')
)
$secretPath = @($secretPaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1)
$recoveryPath = @($recoveryPaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1)
if ($secretPath.Count -eq 0) { $bad.Add('missing protected TOTP secret under tools/totp-vault or tools') }
if ($recoveryPath.Count -eq 0) { $bad.Add('missing protected TOTP recovery store under tools/totp-vault or tools') }
$singleAccount = Test-Path -LiteralPath (Join-Path $vault 'single-account.marker')
foreach ($secretPath in @($secretPath + $recoveryPath)) {
    if (-not $secretPath) { continue }
    try {
        $secretAcl = Get-Acl -LiteralPath $secretPath
        $denyRead = @($secretAcl.Access | Where-Object {
            if ($_.AccessControlType -ne 'Deny') { return $false }
            $identityText = [string]$_.IdentityReference
            if ($identityText -ne $ServiceUser -and -not $identityText.Contains([string][char]92 + $ServiceUser)) { return $false }
            $rightsText = [string]$_.FileSystemRights
            return ($rightsText -match 'Read|ReadData|ReadAttributes|ReadExtendedAttributes|ReadPermissions|FullControl' -or $rightsText -eq 'None')
        })
        if (-not $singleAccount -and $denyRead.Count -eq 0) {
            $bad.Add("missing explicit Deny Read for $ServiceUser on $secretPath")
        }
    } catch {
        $bad.Add("cannot read ACL for ${secretPath}: $($_.Exception.Message)")
    }
}

if ($bad.Count -gt 0) {
    $bad | ForEach-Object { Write-Error $_ }
    exit 1
}
Write-Output 'Broker runtime ACL: OK'
exit 0
